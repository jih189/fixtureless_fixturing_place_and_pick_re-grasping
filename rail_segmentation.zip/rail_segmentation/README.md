rail_segmentation [![Build Status](https://api.travis-ci.org/GT-RAIL/rail_segmentation.png)](https://travis-ci.org/GT-RAIL/rail_segmentation)
=================

#### Segmentation Functionality from the RAIL Lab
For full documentation, see [the ROS wiki](http://ros.org/wiki/rail_segmentation).

### License
rail_segmentation is released with a BSD license. For full terms and conditions, see the [LICENSE](LICENSE) file.

### Authors
See the [AUTHORS.md](AUTHORS.md) file for a full list of contributors.

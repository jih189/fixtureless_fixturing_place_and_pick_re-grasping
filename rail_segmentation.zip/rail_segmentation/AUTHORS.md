Original Authors
----------------

 * [Russell Toris](https://github.com/rctoris/) (russell.toris@gmail.com)
 * [David Kent](https://github.com/dekent/)(dekent@gatech.edu)

Contributors
------------

